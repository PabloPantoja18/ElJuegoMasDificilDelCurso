package elJuegoMasDificilDelCurso;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;

public class AnimationTimerObstaculo extends AnimationTimer{

	@FXML
	private Obstaculo obstaculo_1;
	private Obstaculo obstaculo_2;
	private Obstaculo obstaculo_3;
	private Obstaculo obstaculo_4;
	private Pane paneCancha;
	private Jugador jugador;


	public AnimationTimerObstaculo(Jugador jugador,Obstaculo obstaculo_1, Obstaculo obstaculo_2, Obstaculo obstaculo_3, Obstaculo obstaculo_4,Pane paneCancha) {
		this.obstaculo_1 = obstaculo_1;
		this.obstaculo_2 = obstaculo_2;
		this.obstaculo_3 = obstaculo_3;
		this.obstaculo_4 = obstaculo_4;
		this.paneCancha = paneCancha;
		this.jugador = jugador;
	}


	@Override
	public void handle(long arg0) {

		int x_lim = 430;

		obstaculo_1.mover(x_lim);
		obstaculo_2.mover(x_lim);
		obstaculo_3.mover(x_lim);
		obstaculo_4.mover(x_lim);

		ColisionObstaculos();
		Meta();
	}

	public void ColisionObstaculos() { //PARA LA COLISION CON LOS OBSTACULOS

		if(jugador.getBoundsInParent().intersects((obstaculo_1).getBoundsInParent())) {
			paneCancha.getChildren().remove(jugador);
			jugador.Reinicio();
			paneCancha.getChildren().add(jugador);

		}
		else if(jugador.getBoundsInParent().intersects(obstaculo_2.getBoundsInParent())) {
			paneCancha.getChildren().remove(jugador);
			jugador.Reinicio();
			paneCancha.getChildren().add(jugador);

		}
		else if(jugador.getBoundsInParent().intersects(obstaculo_3.getBoundsInParent())) {
			paneCancha.getChildren().remove(jugador);
			jugador.Reinicio();
			paneCancha.getChildren().add(jugador);

		}
		else if(jugador.getBoundsInParent().intersects(obstaculo_4.getBoundsInParent())) {
			paneCancha.getChildren().remove(jugador);
			jugador.Reinicio();
			paneCancha.getChildren().add(jugador);

		}

	}
	public void Meta() {

		double x = jugador.getX();
		if(x >= 470) {
			System.exit(0);
		}

	}
}