package elJuegoMasDificilDelCurso;

import javafx.scene.shape.Rectangle;

public class Jugador extends Rectangle {

	public Jugador()
	{
		this.setX(80);
		this.setY(120);
		this.setWidth(20);
		this.setHeight(20);
	}

	public void Reinicio() {
		// TODO Auto-generated method stub

		this.setX(80);
		this.setY(120);

	}
}
