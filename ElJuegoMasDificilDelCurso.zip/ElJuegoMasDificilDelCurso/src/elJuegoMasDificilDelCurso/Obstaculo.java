package elJuegoMasDificilDelCurso;

import javafx.scene.shape.Circle;

public class Obstaculo extends Circle {


	private double velocidad;

	public Obstaculo (double x, double y)
	{
		super();

		this.setCenterX(x);
		this.setCenterY(y);
		this.setRadius(10);
		this.velocidad = 2;

	}

	public void mover(double x_lim)
	{
		double x = this.getCenterX();
		double y = this.getCenterY();
		double r = this.getRadius();

		if(x-r <= 170 || x+r >= x_lim)
			velocidad = -velocidad;
		x += velocidad;

		this.setCenterX(x);
		this.setCenterY(y);
	}


}


