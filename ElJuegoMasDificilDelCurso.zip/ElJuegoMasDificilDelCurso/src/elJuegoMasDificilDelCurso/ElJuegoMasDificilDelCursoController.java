package elJuegoMasDificilDelCurso;

import java.io.File;
import java.net.MalformedURLException;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;


public class ElJuegoMasDificilDelCursoController {

	@FXML
	private Pane paneCancha;
	private Jugador jugador;
	private Obstaculo obstaculo_1;
	private Obstaculo obstaculo_2;
	private Obstaculo obstaculo_3;
	private Obstaculo obstaculo_4;
	private AnimationTimerObstaculo miTimer;

	public ElJuegoMasDificilDelCursoController(){

		System.out.println("Constructor del juego mas dificil del curso");

		int x_inicial = 170;  //Dos obstaculos comienzan a moverse desde esa cordenada
		int x_final = 430;    //Los otros dos obstaculos terminan de moverse en esa cordenada
		int y_inicial = 140;   //La altura en que se crearan
		int sep = 29;          //separador en la posicion inicial de los circulos en este caso un numero para sumar o multiplicar
		int radio = 10;

		obstaculo_1 = new Obstaculo(x_inicial+radio+1,y_inicial+radio+1);
		obstaculo_2 = new Obstaculo(x_final-radio-1,y_inicial+radio+sep+1);
		obstaculo_3 = new Obstaculo(x_inicial+radio+1,y_inicial+radio+2*sep+1);
		obstaculo_4 = new Obstaculo(x_final-radio-1,y_inicial+radio+3*sep+1);

	}

	@FXML
	public void initialize() throws MalformedURLException {
		System.out.println("FxPelotaController initializer");

		File imagen_1 = new File("src/elJuegoMasDificilDelCurso/Imagenes/Jugador.png");
		String jugadorimg = imagen_1.toURI().toURL().toString();
		Image jugadorCubo = new Image(jugadorimg);

		File imagen_2 = new File("src/elJuegoMasDificilDelCurso/Imagenes/Obstaculo.png");
		String Obstaculoimg = imagen_2.toURI().toURL().toString();
		Image obstaculo = new Image(Obstaculoimg);

		Rectangle clip = new Rectangle(0, 0, 0,0);
		clip.widthProperty().bind(paneCancha.widthProperty());
		clip.heightProperty().bind(paneCancha.heightProperty());
		paneCancha.setClip(clip);

		jugador = new Jugador();
		jugador.setFill(new ImagePattern(jugadorCubo));
		paneCancha.getChildren().add(jugador);

		obstaculo_1.setFill(new ImagePattern(obstaculo));
		paneCancha.getChildren().add(obstaculo_1);

		obstaculo_2.setFill(new ImagePattern(obstaculo));
		paneCancha.getChildren().add(obstaculo_2);

		obstaculo_3.setFill(new ImagePattern(obstaculo));
		paneCancha.getChildren().add(obstaculo_3);

		obstaculo_4.setFill(new ImagePattern(obstaculo));
		paneCancha.getChildren().add(obstaculo_4);

		miTimer = new AnimationTimerObstaculo(jugador,obstaculo_1,obstaculo_2,obstaculo_3,obstaculo_4,paneCancha);
		miTimer.start();

	}

	@FXML
	public void MovimientoTeclado(KeyEvent keyevent) {

		//PRUEBAS PARA ENCONTRAR LOS LIMITES en el mapa y asi poner las coordenadas correctas para el movimiento
		System.out.println("X: " + jugador.getX() );
		System.out.println("Y: " + jugador.getY());

		double x = jugador.getX();
		double y = jugador.getY();

		switch(keyevent.getCode()) {
		case UP:
		case W:
			//Paredes que se encuentran horizontales hacia arriba
			if(y>=110 && x>=50 && x<=120 && y<=110)
				break;
			if(y>=260 && x>=130 && x<=160 && y<=260)
				break;
			if(y>=140 && x>=170 && x<=400 && y<=140)
				break;
			if(y>=120 && x>=410 && x<=530 && y<=120)
				break;

			y-=10;
			break;
		case DOWN:
		case S:
			//PAREDES HORIZONATLES QUE SE ENCUENTRAN HACIA ABAJO
			if(y>=260 && x>=50 && x<=170 && y<=260)
				break;
			else if(y>=230 && x>=180 && x<=410 && y<=230)
				break;
			else if(y>=120 && x>=420 && x<=450 && y<=120)
				break;
			else if(y>=270 && x>=460 && x<=530 && y<=270)
				break;
			y+=10;
			break;
		case LEFT:
		case A:
			//PAREDES verticales QUE SE ENCUENTRAN A LA IZQUIERDA
		if(x<=50 && y>=100 && y<=270 && x>=50)
				break;
		else if(x<=170 && y>=140 && y<=250 && x>=170)
				break;
		else if(x<=410 && y>=110 && y<=130 && x>=410 )
				break;
		else if(x<=460 && y>=130 && y<=280 && x>=460 )
				break;
			x-=10;
			break;
		case RIGHT:
		case D:
			//PAREDES verticales QUE SE ENCUENTRAN A LA DERECHA
			if(x<=120 && y>=110 && y<=250 && x>=120)
				break;
			else if(x<=170 && y>=240 && y<=260 && x>=170)
				break;
			else if(x<=410 && y>=130 && y<=230 && x>=410)
				break;
			else if(x<=530 && y>=120 && y<=270 && x>=530)
				break;
			x+=10;
			break;
		default:
			System.out.println("MovimientoTeclado:" + keyevent.getCode() );
			break;
		}

		keyevent.consume();

		jugador.setX(x);
		jugador.setY(y);
	}

}
